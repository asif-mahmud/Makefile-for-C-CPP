#include<iostream>
using namespace std;
int main(int argc,char** argv)
{
	int graph[6][6],i,j;
	cout<<"Enter the nodes:";
	for(i=1;i<=6;i++)
	 for(j=1;j<=6;j++)
	 {
		 cout<<"graph["<<i<<"]["<<j<<"]=";
		 cin>>graph[i][j];
	 }
	 for(i=1;i<=6;i++){
		 for(j=1;j<=6;j++){
			 cout<<graph[i][j];
			 cout<<"\t";
		 }
		 cout<<"\n";
	}
	return 0;
}
